package com.example.petstore;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private TextView textViewName;
    private TextView textViewCategory;
    private TextView textViewStatus;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewName = (TextView) findViewById(R.id.textViewName);
        textViewStatus = (TextView) findViewById(R.id.textViewStatus);
        textViewCategory = (TextView) findViewById(R.id.textViewCategory);
        imageView = (ImageView) findViewById(R.id.imageView);
    }
}